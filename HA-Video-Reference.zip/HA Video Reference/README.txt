HA Video Reference
==================

A reference video next to Roblox Studio that follows Heaven's Animator's timeline: scrub, step or play in the
animator and the video moves to the exact same frame. A small Windows app (no browser): it decodes with Windows' own
video decoder and wears Heaven's Animator's theme. The video stays on your computer: nothing is uploaded.

What's in this folder
  HA Video Reference.exe   the app (Windows 10 / 11; nothing to install)
  HA Video Sync.rbxmx      the Studio plugin

Setup (once)
  1. Put "HA Video Sync.rbxmx" in your Studio Plugins folder (Studio > Plugins tab > Plugins Folder) and restart
     Studio. A new toolbar tab "HA Video Reference" appears with a "Video Sync" button.
  2. Keep "HA Video Reference.exe" anywhere you like.

Every time
  1. Open "HA Video Reference.exe" and open a video in it (Open Video..., drop a video on the window, or drop a
     video on the .exe).
  2. In Studio: HA Video Reference tab > Video Sync > Connect (the port must match: 34900 unless you changed it).
     The first time, Studio asks to let the plugin reach "localhost": allow it.
  3. Animate. The video follows Heaven's Animator's frame (full edition or Lite).

In the app
  Start               the Studio frame where the video starts. Earlier / Later (-10 -1 +1 +10) nudge it;
                      Start Here starts it at the frame Studio is on
  Trim                video frames skipped at the video's start
  Speed               how fast the video plays against Studio (1 = real time)
  Loop                play the video again from Start when it ends (otherwise it holds its last frame)
  Mute / Volume       the video's sound
  Mirror              flips the video left / right
  Always on top       keeps the window above Studio
  Middle mouse: pan, wheel: zoom, Home: fit
  The settings are remembered. Phone videos show the right way up.

Trouble
  "App not found"      the app is closed or uses another port: open it again; the port in the plugin and the app
                       must match (default 34900).
  Another port         start it from a command prompt: "HA Video Reference.exe" 34901, then type 34901 in the
                       plugin's Port box.
  "Can't play that video"  Windows has no decoder for it: an mp4 (H.264) always works.
  Windows SmartScreen  the app isn't signed: "More info" > "Run anyway", or right-click the .exe > Properties >
                       Unblock.

Made for Heaven's Animator by MrHxaven. MIT licensed; the source is on GitHub (MrHxaven/ha-video-reference).

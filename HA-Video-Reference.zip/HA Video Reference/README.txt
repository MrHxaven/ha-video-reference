HA Video Reference
==================

Play a reference video next to Roblox Studio that follows Heaven's Animator's timeline: scrub, step or play in the
animator and the video moves to the same moment. Any video your browser can play works (mp4, webm, mov ...). The
video stays on your computer: nothing is uploaded.

What's in this folder
  Start Video Reference.bat   starts the app (Windows; nothing to install)
  server.ps1, player.html     the app itself (a tiny server on this computer only + the video player page)
  HA Video Sync.rbxmx         the Studio plugin

Setup (once)
  1. Put "HA Video Sync.rbxmx" in your Studio Plugins folder (Studio > Plugins tab > Plugins Folder) and restart
     Studio. A new toolbar tab "HA Video Reference" appears with a "Video Sync" button.
  2. Keep the rest of this folder anywhere you like.

Every time
  1. Double-click "Start Video Reference.bat". A small window opens (keep it open) and the player opens in your
     browser.
  2. In the player: Open Video... (or drop a video on it).
  3. In Studio: HA Video Reference tab > Video Sync > Connect. The first time, Studio asks to let the plugin reach
     "localhost": allow it.
  4. Animate. The player follows Heaven's Animator's frame (full edition or Lite).

In the player
  Frame offset        the video time that matches Studio's frame 0, in frames (e.g. 12 skips the first 12 frames)
  Mirror              flips the video left / right
  Sound               the video plays muted unless you turn this on
  Picture in Picture  a small always-on-top video window you can put next to Studio

Trouble
  "Can't reach the app"   the .bat window is closed or uses another port: start it again; the port in the plugin and
                          the window must match (default 34900).
  Another port            run it from a command prompt: "Start Video Reference.bat" 34901, then type 34901 in the
                          plugin's Port box.
  Windows SmartScreen     it is a plain script: "More info" > "Run anyway", or right-click > Properties > Unblock.

Made for Heaven's Animator by MrHxaven.
